# 🇮🇳 BharatTube — Bharat Ki Awaaz, Digital Duniya Mein

> India's premier AI-powered video platform built with Next.js 14, Prisma, and OpenAI

[![Made for Bharat](https://img.shields.io/badge/Made%20for-🇮🇳%20Bharat-FF6B00?style=for-the-badge)](https://bharattube.in)
[![Next.js](https://img.shields.io/badge/Next.js-14-black?style=for-the-badge&logo=next.js)](https://nextjs.org)
[![AI Powered](https://img.shields.io/badge/AI-GPT--4%20Powered-purple?style=for-the-badge)](https://openai.com)

---

## ✨ Features

### 🤖 AI Features
- **Smart Clips Generator** — Auto-detect best moments, generate 30-sec viral clips
- **Auto Subtitles** — Hindi + English transcription using Whisper AI (96%+ accuracy)
- **Multi-Language Dubbing** — Auto-dub in Tamil, Telugu, Bengali, Gujarati, and more
- **AI Thumbnail Generator** — CTR-optimized thumbnails with A/B testing
- **Upload Optimizer** — AI-powered title, tags, and description suggestions
- **Smart Analytics Insights** — AI recommendations for best post time and viral score

### 📹 Video Platform
- 4K video streaming with HLS + CloudFront CDN
- BharatShorts — vertical short-form videos (like Reels/Shorts)
- Live sticker reactions with floating animations
- Real-time view count, likes, comments
- Watch history, playlists, subscriptions

### 📊 Analytics Dashboard
- Real-time views, subscribers, watch hours tracking
- Revenue dashboard with Recharts visualization
- Audience demographics by Indian state
- AI-powered growth insights

### 🇮🇳 India-First Design
- Indian tricolor accent throughout UI
- Hinglish interface (Hindi + English blend)
- Support for 10 Indian languages
- Razorpay integration for payments
- Indian number formatting (Lakh, Crore)

---

## 🚀 Quick Start

```bash
# 1. Clone & install
git clone https://github.com/your-repo/bharattube
cd bharattube
npm install

# 2. Setup environment
cp .env.example .env
# Fill in your API keys in .env

# 3. Setup database
npx prisma db push
npm run db:seed

# 4. Start development
npm run dev
```

Open http://localhost:3000 🎉

---

## 📂 Project Structure

```
bharattube/
├── app/
│   ├── layout.js              # Root layout with Sidebar + Navbar
│   ├── page.js                # Homepage with video feed
│   ├── upload/page.js         # Video upload with AI optimization
│   ├── video/[id]/page.js     # Video player with comments
│   ├── trending/page.js       # Trending videos in India
│   ├── shorts/page.js         # BharatShorts vertical feed
│   ├── analytics/page.js      # Creator analytics dashboard
│   ├── ai-studio/page.js      # AI tools (clips, subtitles, dub)
│   └── api/
│       ├── upload/route.js    # Video upload API
│       ├── videos/route.js    # Video CRUD API
│       ├── ai-suggest/route.js # AI optimization API
│       └── analytics/route.js # Analytics API
├── components/
│   ├── Navbar.jsx             # Top navigation bar
│   ├── Sidebar.jsx            # Left sidebar with navigation
│   ├── VideoCard.jsx          # Video card component
│   └── StickersPanel.jsx      # Live sticker reactions
├── lib/
│   ├── db.js                  # Prisma client singleton
│   └── utils.js               # Helper functions (Indian formatting)
├── prisma/
│   ├── schema.prisma          # Database schema
│   └── seed.js                # Database seeder
├── public/                    # Static assets
├── tailwind.config.js         # Tailwind + custom Bharat theme
└── package.json
```

---

## 🗄️ Database Models

| Model | Description |
|-------|-------------|
| `User` | Creator profiles with channel info |
| `Video` | Videos with AI metadata |
| `Comment` | Threaded comments |
| `Like` | Video likes |
| `Subscription` | Channel subscriptions |
| `Notification` | User notifications |
| `WatchHistory` | Watch history with progress |
| `VideoAnalytics` | Daily analytics per video |
| `Sticker` | Sticker catalog |
| `Trending` | Trending score tracker |

---

## 🔧 Environment Variables

```env
DATABASE_URL="file:./dev.db"          # SQLite (use PostgreSQL for production)
NEXTAUTH_SECRET="your-secret"
OPENAI_API_KEY="sk-..."               # For AI features
AWS_ACCESS_KEY_ID="..."               # For S3 video storage
AWS_SECRET_ACCESS_KEY="..."
AWS_S3_BUCKET="bharattube-videos"
AWS_REGION="ap-south-1"              # Mumbai region for India
RAZORPAY_KEY_ID="..."                 # Indian payments
```

---

## 🌐 Production Deployment

### Vercel (Recommended)
```bash
vercel --prod
```

### Docker
```bash
docker build -t bharattube .
docker run -p 3000:3000 bharattube
```

### Self-hosted (Ubuntu)
```bash
npm run build
pm2 start npm --name bharattube -- start
```

---

## 🛠️ Tech Stack

| Category | Technology |
|----------|-----------|
| Framework | Next.js 14 (App Router) |
| Database | SQLite (dev) / PostgreSQL (prod) |
| ORM | Prisma |
| Auth | NextAuth.js |
| AI | OpenAI GPT-4 + Whisper |
| Storage | AWS S3 + CloudFront |
| Charts | Recharts |
| Styling | Tailwind CSS |
| Animations | Framer Motion |
| Payments | Razorpay (India) |

---

## 📱 Pages

| Route | Page |
|-------|------|
| `/` | Homepage feed |
| `/trending` | Trending in India |
| `/shorts` | BharatShorts |
| `/upload` | Upload video |
| `/video/:id` | Video player |
| `/analytics` | Creator analytics |
| `/ai-studio` | AI tools |
| `/profile` | Creator profile |

---

## 🙏 Made with ❤️ for Bharat

Jai Hind! 🇮🇳
