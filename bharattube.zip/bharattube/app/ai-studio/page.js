'use client'
import { useState } from 'react'
import { HiSparkles } from 'react-icons/hi2'
import { MdAutoAwesome, MdVideoFile, MdSubtitles, MdTranslate, MdContentCut, MdThumbUp } from 'react-icons/md'
import toast from 'react-hot-toast'

const AI_TOOLS = [
  {
    id: 'clips',
    icon: <MdContentCut size={28} />,
    title: 'Smart Clips Generator',
    desc: 'Video ke best moments ko auto-detect karke 30-sec clips banao',
    badge: '🔥 Most Used',
    badgeColor: 'bg-bharat-saffron/20 text-bharat-saffron border-bharat-saffron/30',
    action: 'Generate Clips',
  },
  {
    id: 'subtitles',
    icon: <MdSubtitles size={28} />,
    title: 'Auto Subtitles',
    desc: 'Hindi aur English mein automatic subtitles generate karo (SRT/VTT)',
    badge: '✨ New',
    badgeColor: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    action: 'Generate Subtitles',
  },
  {
    id: 'translate',
    icon: <MdTranslate size={28} />,
    title: 'Multi-Language Dub',
    desc: 'Video ko Tamil, Telugu, Bengali, Gujarati mein auto-dub karo',
    badge: '🇮🇳 India Special',
    badgeColor: 'bg-bharat-green/20 text-bharat-green border-bharat-green/30',
    action: 'Start Dubbing',
  },
  {
    id: 'thumbnail',
    icon: <MdThumbUp size={28} />,
    title: 'AI Thumbnail Generator',
    desc: 'CTR-optimized thumbnails AI se generate karo, A/B test karo',
    badge: '📈 +47% CTR',
    badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    action: 'Create Thumbnail',
  },
]

const LANGUAGE_OPTIONS = ['Tamil', 'Telugu', 'Bengali', 'Gujarati', 'Marathi', 'Punjabi', 'Kannada', 'Malayalam']

export default function AIStudioPage() {
  const [activeTool, setActiveTool] = useState(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [processing, setProcessing] = useState(false)
  const [result, setResult] = useState(null)
  const [selectedLangs, setSelectedLangs] = useState([])

  const handleProcess = async () => {
    if (!videoUrl && !activeTool) { toast.error('Pehle tool select karo'); return }
    if (!videoUrl) { toast.error('Video URL paste karo'); return }

    setProcessing(true)
    setResult(null)

    // Simulate AI processing
    await new Promise(r => setTimeout(r, 3000))

    if (activeTool === 'clips') {
      setResult({
        type: 'clips',
        clips: [
          { start: '02:15', end: '02:45', score: 98, label: '🔥 Most Exciting' },
          { start: '08:30', end: '09:00', score: 94, label: '😂 Funniest Moment' },
          { start: '15:20', end: '15:50', score: 91, label: '💡 Key Insight' },
          { start: '22:10', end: '22:40', score: 87, label: '🎯 Call to Action' },
        ]
      })
    } else if (activeTool === 'subtitles') {
      setResult({
        type: 'subtitles',
        preview: `00:00:02,500 --> 00:00:05,000\nNamaste doston, aaj hum baat karenge...\n\n00:00:05,500 --> 00:00:08,200\nIs video mein aap seekhenge...\n\n00:00:09,000 --> 00:00:12,000\nToh chaliye shuru karte hain!`,
        wordCount: 2847,
        accuracy: '96.4%'
      })
    } else {
      setResult({ type: 'generic', message: 'Processing complete! ✅' })
    }

    setProcessing(false)
    toast.success('AI processing complete! 🎉')
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-5xl mx-auto">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 badge bg-bharat-saffron/20 text-bharat-saffron 
                         border border-bharat-saffron/30 mb-4 px-4 py-2 text-sm">
            <HiSparkles className="text-lg" />
            Powered by GPT-4 + Whisper AI
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-3">
            🤖 AI <span className="gradient-text">Studio</span>
          </h1>
          <p className="text-white/50 text-lg">
            Apne videos ko AI se supercharge karo — Bharat ke liye, Bharat ki zubaan mein
          </p>
        </div>

        {/* Tools Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {AI_TOOLS.map(tool => (
            <button key={tool.id}
              onClick={() => setActiveTool(activeTool === tool.id ? null : tool.id)}
              className={`card p-6 text-left transition-all duration-300 group
                         ${activeTool === tool.id
                           ? 'border-bharat-saffron/50 bg-bharat-saffron/5 shadow-xl shadow-orange-500/10'
                           : 'hover:border-white/20'}`}>
              <div className="flex items-start gap-4">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0
                               transition-all duration-300
                               ${activeTool === tool.id
                                 ? 'bg-bharat-saffron text-white'
                                 : 'bg-white/5 text-white/40 group-hover:bg-bharat-saffron/10 group-hover:text-bharat-saffron'}`}>
                  {tool.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white text-sm">{tool.title}</h3>
                    <span className={`badge border text-[10px] ${tool.badgeColor}`}>
                      {tool.badge}
                    </span>
                  </div>
                  <p className="text-white/40 text-xs leading-relaxed">{tool.desc}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Input Section */}
        {activeTool && (
          <div className="card p-6 mb-6 animate-slide-up">
            <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
              <MdVideoFile className="text-bharat-saffron" />
              {AI_TOOLS.find(t => t.id === activeTool)?.title}
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-white/40 font-semibold uppercase tracking-wider mb-2 block">
                  Video URL (YouTube / BharatTube / S3)
                </label>
                <input
                  value={videoUrl}
                  onChange={e => setVideoUrl(e.target.value)}
                  placeholder="https://bharattube.in/video/xyz ya YouTube URL paste karo..."
                  className="input-field"
                />
              </div>

              {activeTool === 'translate' && (
                <div>
                  <label className="text-xs text-white/40 font-semibold uppercase tracking-wider mb-2 block">
                    Target Languages (multiple select karo)
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {LANGUAGE_OPTIONS.map(lang => (
                      <button key={lang}
                        onClick={() => setSelectedLangs(prev =>
                          prev.includes(lang) ? prev.filter(l => l !== lang) : [...prev, lang]
                        )}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border
                                   ${selectedLangs.includes(lang)
                                     ? 'bg-bharat-saffron/20 text-bharat-saffron border-bharat-saffron/30'
                                     : 'bg-white/5 text-white/50 border-white/10 hover:text-white'}`}>
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button
                onClick={handleProcess}
                disabled={processing}
                className="btn-primary w-full py-4 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-3">
                {processing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    AI Processing ho raha hai...
                  </>
                ) : (
                  <>
                    <MdAutoAwesome className="text-xl" />
                    {AI_TOOLS.find(t => t.id === activeTool)?.action}
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="card p-6 animate-slide-up">
            <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
              <HiSparkles className="text-bharat-saffron" />
              AI Results Ready! ✅
            </h3>

            {result.type === 'clips' && (
              <div className="space-y-3">
                <p className="text-white/40 text-sm mb-4">
                  {result.clips.length} best moments mila aapke video mein:
                </p>
                {result.clips.map((clip, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 bg-white/3 rounded-xl border border-white/5">
                    <div className="w-10 h-10 rounded-xl bg-bharat-saffron/20 border border-bharat-saffron/30 
                                   flex items-center justify-center text-xs font-bold text-bharat-saffron">
                      {clip.score}%
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{clip.label}</p>
                      <p className="text-xs text-white/40">{clip.start} → {clip.end}</p>
                    </div>
                    <button className="btn-secondary text-xs py-1.5 px-3">Download</button>
                  </div>
                ))}
              </div>
            )}

            {result.type === 'subtitles' && (
              <div className="space-y-4">
                <div className="flex gap-4 text-sm">
                  <span className="text-white/50">Words: <span className="text-white font-semibold">{result.wordCount}</span></span>
                  <span className="text-white/50">Accuracy: <span className="text-bharat-green font-semibold">{result.accuracy}</span></span>
                </div>
                <div className="bg-black/40 rounded-xl p-4 font-mono text-xs text-white/60 leading-relaxed">
                  <pre>{result.preview}</pre>
                </div>
                <div className="flex gap-3">
                  <button className="btn-primary text-sm py-2 px-5">Download SRT</button>
                  <button className="btn-secondary text-sm py-2 px-5">Download VTT</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-8">
          {[
            { value: '50L+', label: 'Clips Generated' },
            { value: '99.2%', label: 'AI Accuracy' },
            { value: '12', label: 'Indian Languages' },
          ].map((s, i) => (
            <div key={i} className="card p-5 text-center">
              <p className="font-display text-2xl font-bold gradient-text mb-1">{s.value}</p>
              <p className="text-white/40 text-xs">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
