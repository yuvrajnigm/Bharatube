'use client'
import { useState } from 'react'
import { 
  MdBarChart, MdVisibility, MdThumbUp, MdPeople,
  MdTrendingUp, MdWatchLater, MdOutlineVideoLibrary,
  MdArrowUpward, MdArrowDownward
} from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area
} from 'recharts'

const viewsData = [
  { date: '1 Nov', views: 12000, revenue: 480 },
  { date: '5 Nov', views: 19000, revenue: 760 },
  { date: '10 Nov', views: 15000, revenue: 600 },
  { date: '15 Nov', views: 28000, revenue: 1120 },
  { date: '20 Nov', views: 35000, revenue: 1400 },
  { date: '25 Nov', views: 42000, revenue: 1680 },
  { date: '30 Nov', views: 38000, revenue: 1520 },
  { date: '5 Dec', views: 51000, revenue: 2040 },
  { date: '10 Dec', views: 63000, revenue: 2520 },
  { date: '15 Dec', views: 58000, revenue: 2320 },
  { date: '20 Dec', views: 74000, revenue: 2960 },
  { date: '25 Dec', views: 89000, revenue: 3560 },
]

const topVideos = [
  { title: 'Dilli Market Tour', views: 1200000, likes: 48000, revenue: '₹24,000', growth: 12.4 },
  { title: 'AI Guide Hindi', views: 890000, likes: 32000, revenue: '₹18,500', growth: 8.2 },
  { title: 'IPL Best Moments', views: 3400000, likes: 145000, revenue: '₹68,000', growth: 24.1 },
  { title: 'Street Food Mumbai', views: 670000, likes: 28000, revenue: '₹14,200', growth: -3.2 },
  { title: 'Python Hindi', views: 780000, likes: 35000, revenue: '₹16,800', growth: 15.7 },
]

const audienceData = [
  { state: 'Maharashtra', percent: 22 },
  { state: 'UP', percent: 18 },
  { state: 'Delhi', percent: 15 },
  { state: 'Karnataka', percent: 12 },
  { state: 'Tamil Nadu', percent: 9 },
  { state: 'Others', percent: 24 },
]

const STAT_CARDS = [
  { icon: <MdVisibility />, label: 'Total Views', value: '1.2Cr', change: '+18.4%', up: true, color: 'from-bharat-saffron to-orange-500' },
  { icon: <MdPeople />, label: 'Subscribers', value: '12.4L', change: '+5.2K', up: true, color: 'from-purple-500 to-purple-700' },
  { icon: <MdThumbUp />, label: 'Total Likes', value: '45.6L', change: '+12.1%', up: true, color: 'from-bharat-green to-green-600' },
  { icon: <MdWatchLater />, label: 'Watch Hours', value: '8.9L hrs', change: '+22.3%', up: true, color: 'from-blue-500 to-blue-700' },
  { icon: <MdBarChart />, label: 'Revenue (MTD)', value: '₹1.84L', change: '+31.2%', up: true, color: 'from-yellow-500 to-orange-500' },
  { icon: <MdOutlineVideoLibrary />, label: 'Total Videos', value: '156', change: '+8 this month', up: true, color: 'from-pink-500 to-rose-600' },
]

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-bharat-card border border-bharat-border rounded-xl p-3 shadow-2xl">
        <p className="text-white/50 text-xs mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} className="text-sm font-semibold" style={{ color: p.color }}>
            {p.name}: {typeof p.value === 'number' && p.name === 'revenue' ? '₹' : ''}
            {p.value?.toLocaleString('en-IN')}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export default function AnalyticsPage() {
  const [period, setPeriod] = useState('30d')
  const [activeTab, setActiveTab] = useState('overview')

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl font-bold text-white mb-1">
              📊 Channel Analytics
            </h1>
            <p className="text-white/40 text-sm">Apne channel ki real-time performance dekho</p>
          </div>
          <div className="flex gap-2">
            {['7d', '30d', '90d', '1y'].map(p => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all
                           ${period === p
                             ? 'bg-bharat-saffron text-white shadow-lg shadow-orange-500/30'
                             : 'bg-white/5 text-white/50 border border-white/10 hover:text-white'}`}>
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* AI Insight Banner */}
        <div className="bg-gradient-to-r from-purple-500/10 to-bharat-saffron/10 
                       border border-purple-500/20 rounded-2xl p-5 mb-6 flex items-start gap-4">
          <HiSparkles className="text-bharat-saffron text-2xl flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-white text-sm mb-1">🤖 AI Insight</p>
            <p className="text-white/60 text-sm leading-relaxed">
              Teri "IPL Best Moments" video is hafte <span className="text-bharat-saffron font-semibold">+24.1%</span> grow ki. 
              Weekend pe sports content zyada viral hota hai. Agli video <span className="text-bharat-saffron font-semibold">Friday ya Saturday</span> ko post karo 
              — expected reach <span className="text-bharat-saffron font-semibold">40% zyada</span> hogi.
            </p>
          </div>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          {STAT_CARDS.map((stat, i) => (
            <div key={i} className="card p-4">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} 
                              flex items-center justify-center text-white text-lg mb-3`}>
                {stat.icon}
              </div>
              <p className="text-white/40 text-xs mb-1">{stat.label}</p>
              <p className="font-display font-bold text-white text-xl leading-none mb-1">
                {stat.value}
              </p>
              <div className={`flex items-center gap-1 text-xs font-semibold
                              ${stat.up ? 'text-bharat-green' : 'text-red-400'}`}>
                {stat.up ? <MdArrowUpward size={14} /> : <MdArrowDownward size={14} />}
                {stat.change}
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-white/5 p-1 rounded-xl w-fit">
          {['overview', 'audience', 'revenue', 'videos'].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all
                         ${activeTab === tab
                           ? 'bg-bharat-saffron text-white shadow-lg'
                           : 'text-white/50 hover:text-white'}`}>
              {tab}
            </button>
          ))}
        </div>

        {/* Charts */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Views Chart */}
            <div className="card p-5">
              <h3 className="font-semibold text-white mb-4 text-sm">Views Over Time</h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={viewsData}>
                  <defs>
                    <linearGradient id="viewsGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#FF6B00" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#FF6B00" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => (v/1000) + 'K'} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="views" name="Views" stroke="#FF6B00" strokeWidth={2} fill="url(#viewsGrad)" dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Revenue Chart */}
            <div className="card p-5">
              <h3 className="font-semibold text-white mb-4 text-sm">Revenue (₹)</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={viewsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} tickLine={false} axisLine={false} />
                  <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} tickLine={false} axisLine={false} tickFormatter={v => '₹' + (v/1000).toFixed(1) + 'K'} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="revenue" name="revenue" fill="#138808" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {activeTab === 'audience' && (
          <div className="card p-5 mb-6">
            <h3 className="font-semibold text-white mb-4">Audience by State</h3>
            <div className="space-y-3">
              {audienceData.map((d, i) => (
                <div key={i} className="flex items-center gap-4">
                  <span className="text-white/60 text-sm w-24">{d.state}</span>
                  <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-bharat-saffron to-orange-400 rounded-full transition-all duration-700"
                      style={{ width: `${d.percent}%` }}
                    />
                  </div>
                  <span className="text-bharat-saffron font-semibold text-sm w-10 text-right">{d.percent}%</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Top Videos Table */}
        {(activeTab === 'overview' || activeTab === 'videos') && (
          <div className="card overflow-hidden">
            <div className="p-5 border-b border-bharat-border">
              <h3 className="font-semibold text-white text-sm">Top Videos</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-bharat-border">
                    {['Video', 'Views', 'Likes', 'Revenue', 'Growth'].map(h => (
                      <th key={h} className="text-left text-xs text-white/30 font-semibold 
                                             uppercase tracking-wider px-5 py-3">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {topVideos.map((v, i) => (
                    <tr key={i} className="border-b border-white/5 hover:bg-white/3 transition-colors">
                      <td className="px-5 py-4 text-sm text-white font-medium">{v.title}</td>
                      <td className="px-5 py-4 text-sm text-white/60">{(v.views/100000).toFixed(1)}L</td>
                      <td className="px-5 py-4 text-sm text-white/60">{(v.likes/1000).toFixed(0)}K</td>
                      <td className="px-5 py-4 text-sm text-bharat-green font-semibold">{v.revenue}</td>
                      <td className="px-5 py-4">
                        <span className={`badge font-semibold text-xs
                                         ${v.growth > 0
                                           ? 'bg-bharat-green/10 text-bharat-green border border-bharat-green/20'
                                           : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                          {v.growth > 0 ? '▲' : '▼'} {Math.abs(v.growth)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
