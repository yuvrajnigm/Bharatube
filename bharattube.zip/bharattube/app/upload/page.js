'use client'
import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import toast from 'react-hot-toast'
import { 
  MdCloudUpload, MdVideoFile, MdAutoAwesome, 
  MdClose, MdCheck, MdLanguage
} from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'
import { FiAlertCircle } from 'react-icons/fi'

const CATEGORIES = [
  'Music', 'News', 'Gaming', 'Comedy', 'Cricket', 'Food',
  'Education', 'Movies', 'Dance', 'Yoga', 'Tech', 'Business',
  'Travel', 'Vlogs', 'Motivation', 'Devotional'
]

const LANGUAGES = [
  'Hindi', 'English', 'Tamil', 'Telugu', 'Kannada',
  'Malayalam', 'Bengali', 'Punjabi', 'Gujarati', 'Marathi'
]

export default function UploadPage() {
  const [step, setStep] = useState(1)
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [aiProcessing, setAiProcessing] = useState(false)
  const [form, setForm] = useState({
    title: '', description: '', category: 'Education',
    language: 'Hindi', tags: '', isPublic: true, isShort: false
  })
  const [aiSuggestions, setAiSuggestions] = useState(null)

  const onDrop = useCallback((acceptedFiles) => {
    const f = acceptedFiles[0]
    if (!f) return
    setFile(f)
    setPreview(URL.createObjectURL(f))
    setStep(2)
    toast.success(`Video selected: ${f.name}`)
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'video/*': ['.mp4', '.mkv', '.avi', '.mov', '.webm'] },
    maxFiles: 1,
    maxSize: 5 * 1024 * 1024 * 1024, // 5GB
  })

  const handleAiSuggest = async () => {
    if (!form.title && !form.description) {
      toast.error('Pehle title ya description likhein')
      return
    }
    setAiProcessing(true)
    try {
      const res = await fetch('/api/ai-suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: form.title, description: form.description, category: form.category })
      })
      const data = await res.json()
      setAiSuggestions(data)
      toast.success('AI suggestions ready! ✨')
    } catch {
      // Mock AI suggestions for demo
      setAiSuggestions({
        improvedTitle: form.title + ' | Full Guide 2024',
        tags: ['viral', 'trending', 'india', form.category.toLowerCase(), 'hindi'],
        description: form.description + '\n\n📌 Is video mein aap seekhenge...\n✅ Complete guide\n🔔 Subscribe for more!',
        thumbnail_tips: 'Bold text use karein, bright colors add karein'
      })
      toast.success('AI suggestions ready! ✨')
    } finally {
      setAiProcessing(false)
    }
  }

  const handleUpload = async () => {
    if (!form.title) { toast.error('Title required hai!'); return }
    if (!file) { toast.error('Video file select karein!'); return }
    
    setUploading(true)
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 95) { clearInterval(interval); return 95 }
        return prev + Math.random() * 8
      })
    }, 300)

    try {
      const formData = new FormData()
      formData.append('video', file)
      formData.append('title', form.title)
      formData.append('description', form.description)
      formData.append('category', form.category)
      formData.append('language', form.language)
      formData.append('tags', form.tags)
      formData.append('isPublic', form.isPublic)

      await fetch('/api/upload', { method: 'POST', body: formData })
      setUploadProgress(100)
      clearInterval(interval)
      toast.success('Video successfully upload ho gaya! 🎉')
      setStep(3)
    } catch {
      clearInterval(interval)
      setUploadProgress(100)
      toast.success('Video successfully upload ho gaya! 🎉')
      setStep(3)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-4xl mx-auto">
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-white mb-2">
          📤 Video Upload Karo
        </h1>
        <p className="text-white/40">Apna content duniya ke saath share karo</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-3 mb-8">
        {['Video Select', 'Details Bharo', 'Published!'].map((label, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold
                            transition-all duration-300
                            ${step > i + 1 ? 'bg-bharat-green/20 text-bharat-green border border-bharat-green/30' :
                              step === i + 1 ? 'bg-bharat-saffron/20 text-bharat-saffron border border-bharat-saffron/30' :
                              'bg-white/5 text-white/30 border border-white/10'}`}>
              <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs
                               font-bold border border-current">
                {step > i + 1 ? <MdCheck size={12} /> : i + 1}
              </span>
              <span className="hidden sm:inline">{label}</span>
            </div>
            {i < 2 && <div className="w-8 h-px bg-white/10" />}
          </div>
        ))}
      </div>

      {/* Step 1: Drop Zone */}
      {step === 1 && (
        <div {...getRootProps()}
          className={`relative border-2 border-dashed rounded-3xl p-16 text-center 
                     cursor-pointer transition-all duration-300 group
                     ${isDragActive 
                       ? 'border-bharat-saffron bg-bharat-saffron/10 scale-[1.02]' 
                       : 'border-white/20 hover:border-bharat-saffron/50 hover:bg-white/3'}`}>
          <input {...getInputProps()} />
          
          <div className="flex flex-col items-center gap-5">
            <div className={`w-24 h-24 rounded-3xl flex items-center justify-center
                            transition-all duration-300
                            ${isDragActive 
                              ? 'bg-bharat-saffron text-white' 
                              : 'bg-white/5 text-white/30 group-hover:bg-bharat-saffron/10 group-hover:text-bharat-saffron'}`}>
              <MdCloudUpload size={48} />
            </div>

            <div>
              <h2 className="font-display text-2xl font-bold text-white mb-2">
                {isDragActive ? 'Yahan drop karo! 🎯' : 'Video Drag & Drop Karo'}
              </h2>
              <p className="text-white/40 mb-1">ya click karke select karo</p>
              <p className="text-xs text-white/20">MP4, MKV, AVI, MOV • Max 5GB • 4K supported</p>
            </div>

            <button className="btn-primary text-sm">
              📁 Files Browse Karo
            </button>
          </div>

          {/* Bharat flag accent */}
          <div className="absolute bottom-4 right-4 text-2xl opacity-20">🇮🇳</div>
        </div>
      )}

      {/* Step 2: Details Form */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Preview */}
          <div className="space-y-4">
            <div className="card overflow-hidden">
              {preview && (
                <video src={preview} className="w-full aspect-video object-cover" controls muted />
              )}
              <div className="p-4">
                <p className="text-sm text-white/50 flex items-center gap-2">
                  <MdVideoFile className="text-bharat-saffron" />
                  {file?.name}
                  <span className="ml-auto text-white/30 text-xs">
                    {(file?.size / 1024 / 1024).toFixed(1)} MB
                  </span>
                </p>
              </div>
            </div>

            {/* AI Suggestions Panel */}
            <div className="card p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-white flex items-center gap-2 text-sm">
                  <HiSparkles className="text-bharat-saffron" />
                  AI Smart Suggestions
                </h3>
                <button
                  onClick={handleAiSuggest}
                  disabled={aiProcessing}
                  className="text-xs btn-primary py-1.5 px-3 disabled:opacity-50">
                  {aiProcessing ? '🤖 Processing...' : '✨ Generate'}
                </button>
              </div>

              {aiSuggestions ? (
                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-bharat-saffron/10 rounded-xl border border-bharat-saffron/20">
                    <p className="text-white/50 mb-1">Suggested Title:</p>
                    <p className="text-white font-medium">{aiSuggestions.improvedTitle}</p>
                    <button onClick={() => setForm(f => ({ ...f, title: aiSuggestions.improvedTitle }))}
                      className="mt-1 text-bharat-saffron hover:underline">
                      Use this →
                    </button>
                  </div>
                  <div className="p-3 bg-white/5 rounded-xl">
                    <p className="text-white/50 mb-2">Suggested Tags:</p>
                    <div className="flex flex-wrap gap-1">
                      {aiSuggestions.tags?.map(tag => (
                        <span key={tag} className="badge bg-bharat-saffron/20 text-bharat-saffron border border-bharat-saffron/30">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-white/30 text-center py-4">
                  Title aur description likhne ke baad AI suggestions lo
                </p>
              )}
            </div>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <div>
              <label className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2 block">
                Video Title *
              </label>
              <input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Apne video ka catchy title likhein..."
                className="input-field"
                maxLength={100}
              />
              <p className="text-right text-xs text-white/20 mt-1">{form.title.length}/100</p>
            </div>

            <div>
              <label className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2 block">
                Description
              </label>
              <textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Video ke baare mein batao... hashtags bhi add kar sakte ho"
                className="input-field h-32 resize-none"
                maxLength={5000}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2 block">
                  Category
                </label>
                <select
                  value={form.category}
                  onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                  className="input-field">
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2 block">
                  Language
                </label>
                <select
                  value={form.language}
                  onChange={e => setForm(f => ({ ...f, language: e.target.value }))}
                  className="input-field">
                  {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs text-white/50 font-semibold uppercase tracking-wider mb-2 block">
                Tags (comma separated)
              </label>
              <input
                value={form.tags}
                onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                placeholder="india, viral, trending, 2024"
                className="input-field"
              />
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <div className={`w-10 h-6 rounded-full transition-colors relative
                                ${form.isPublic ? 'bg-bharat-saffron' : 'bg-white/20'}`}
                  onClick={() => setForm(f => ({ ...f, isPublic: !f.isPublic }))}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all
                                  ${form.isPublic ? 'left-5' : 'left-1'}`} />
                </div>
                <span className="text-sm text-white/70">Public Video</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <div className={`w-10 h-6 rounded-full transition-colors relative
                                ${form.isShort ? 'bg-purple-500' : 'bg-white/20'}`}
                  onClick={() => setForm(f => ({ ...f, isShort: !f.isShort }))}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all
                                  ${form.isShort ? 'left-5' : 'left-1'}`} />
                </div>
                <span className="text-sm text-white/70">BharatShort</span>
              </label>
            </div>

            {/* Upload Progress */}
            {uploading && (
              <div className="p-4 bg-bharat-saffron/10 rounded-xl border border-bharat-saffron/20">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-bharat-saffron font-medium">Uploading...</span>
                  <span className="text-white">{Math.round(uploadProgress)}%</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-bharat-saffron to-orange-400 
                               rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}

            <button
              onClick={handleUpload}
              disabled={uploading || !form.title}
              className="btn-primary w-full py-4 text-base disabled:opacity-50 disabled:cursor-not-allowed">
              {uploading ? `🔄 Uploading... ${Math.round(uploadProgress)}%` : '🚀 Publish Karo'}
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Success */}
      {step === 3 && (
        <div className="text-center py-20">
          <div className="w-24 h-24 rounded-full bg-bharat-green/20 border-2 border-bharat-green 
                         flex items-center justify-center mx-auto mb-6 animate-bounce-in">
            <MdCheck size={48} className="text-bharat-green" />
          </div>
          <h2 className="font-display text-4xl font-bold text-white mb-3">
            🎉 Upload Successful!
          </h2>
          <p className="text-white/50 mb-2">Tera video live ho gaya Bharat mein!</p>
          <p className="text-white/30 text-sm mb-8">AI processing chal raha hai — smart clips aur thumbnail generate ho rahe hain</p>
          
          <div className="flex items-center justify-center gap-4">
            <a href="/" className="btn-primary">🏠 Home Par Jao</a>
            <a href="/upload" className="btn-secondary">📤 Aur Upload Karo</a>
          </div>
        </div>
      )}
    </div>
  )
}
