import './globals.css'
import { Toaster } from 'react-hot-toast'
import Sidebar from '@/components/Sidebar'
import Navbar from '@/components/Navbar'

export const metadata = {
  title: 'BharatTube — Bharat Ki Awaaz, Digital Duniya Mein',
  description: 'India\'s premier AI-powered video platform. Watch, upload, and share videos in Hindi, English, and all Indian languages.',
  keywords: 'bharattube, india video platform, hindi videos, indian content',
  openGraph: {
    title: 'BharatTube',
    description: 'Bharat Ki Awaaz, Digital Duniya Mein',
    images: ['/og-image.png'],
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;600;700;800&family=Noto+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body className="animated-bg min-h-screen text-white">
        {/* Tricolor top bar */}
        <div className="tricolor-line fixed top-0 left-0 right-0 z-50" />

        <div className="flex pt-[3px]">
          {/* Sidebar */}
          <Sidebar />

          {/* Main content */}
          <div className="flex-1 ml-0 lg:ml-64">
            <Navbar />
            <main className="pt-16">
              {children}
            </main>
          </div>
        </div>

        <Toaster
          position="bottom-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#12121A',
              color: '#F5F5F5',
              border: '1px solid #1E1E2E',
              borderRadius: '12px',
            },
          }}
        />
      </body>
    </html>
  )
}
