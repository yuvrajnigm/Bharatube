'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import VideoCard from '@/components/VideoCard'
import StickersPanel from '@/components/StickersPanel'
import { MdLocalFireDepartment, MdOutlineAutoAwesome, MdPlayArrow } from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'
import { FiTrendingUp } from 'react-icons/fi'

const CATEGORIES = [
  { label: 'All', emoji: '🌐' },
  { label: 'Music', emoji: '🎵' },
  { label: 'News', emoji: '📰' },
  { label: 'Gaming', emoji: '🎮' },
  { label: 'Comedy', emoji: '😄' },
  { label: 'Cricket', emoji: '🏏' },
  { label: 'Food', emoji: '🍛' },
  { label: 'Education', emoji: '📚' },
  { label: 'Movies', emoji: '🎬' },
  { label: 'Dance', emoji: '💃' },
  { label: 'Yoga', emoji: '🧘' },
  { label: 'Tech', emoji: '💻' },
]

const MOCK_VIDEOS = [
  { id: '1', title: 'Dilli Ki Sabse Badi Market Tour 2024', thumbnail: 'https://picsum.photos/seed/v1/640/360', views: 1200000, duration: '18:42', channelName: 'Desi Explorer', avatar: 'D', createdAt: '2 din pehle', isVerified: true, category: 'Travel' },
  { id: '2', title: 'AI se Paise Kamao - Complete Guide Hindi', thumbnail: 'https://picsum.photos/seed/v2/640/360', views: 890000, duration: '24:15', channelName: 'TechGuru India', avatar: 'T', createdAt: '5 din pehle', isVerified: true, category: 'Education' },
  { id: '3', title: 'IPL 2024 Best Moments Compilation', thumbnail: 'https://picsum.photos/seed/v3/640/360', views: 3400000, duration: '12:30', channelName: 'Cricket Adda', avatar: 'C', createdAt: '1 hafta pehle', isVerified: true, category: 'Cricket' },
  { id: '4', title: 'Street Food Mumbai - 50 Rupay Mein Kya Milta Hai', thumbnail: 'https://picsum.photos/seed/v4/640/360', views: 670000, duration: '15:22', channelName: 'Food Wanderer', avatar: 'F', createdAt: '3 din pehle', isVerified: false, category: 'Food' },
  { id: '5', title: 'Rajasthan Road Trip - Jaipur se Jaisalmer', thumbnail: 'https://picsum.photos/seed/v5/640/360', views: 445000, duration: '32:10', channelName: 'Desi Traveler', avatar: 'D', createdAt: '1 din pehle', isVerified: true, category: 'Travel' },
  { id: '6', title: 'Bollywood Dance Tutorial - Trending Reels Steps', thumbnail: 'https://picsum.photos/seed/v6/640/360', views: 2100000, duration: '8:45', channelName: 'Dance India Dance', avatar: 'D', createdAt: '4 din pehle', isVerified: true, category: 'Dance' },
  { id: '7', title: 'Python Programming - Zero to Hero Hindi Mein', thumbnail: 'https://picsum.photos/seed/v7/640/360', views: 780000, duration: '45:20', channelName: 'Code with Ravi', avatar: 'R', createdAt: '6 din pehle', isVerified: true, category: 'Education' },
  { id: '8', title: 'Stand-up Comedy - Shaadi Mein Kya Hota Hai', thumbnail: 'https://picsum.photos/seed/v8/640/360', views: 1560000, duration: '22:00', channelName: 'Hasao Hasao', avatar: 'H', createdAt: '2 hafta pehle', isVerified: true, category: 'Comedy' },
  { id: '9', title: 'Yoga for Beginners - 30 Din Ka Plan', thumbnail: 'https://picsum.photos/seed/v9/640/360', views: 320000, duration: '28:15', channelName: 'Fit Bharat', avatar: 'F', createdAt: '3 din pehle', isVerified: false, category: 'Yoga' },
  { id: '10', title: 'Budget Smartphone 2024 - Best 5 Under 15000', thumbnail: 'https://picsum.photos/seed/v10/640/360', views: 990000, duration: '16:40', channelName: 'Tech Dost', avatar: 'T', createdAt: '1 din pehle', isVerified: true, category: 'Tech' },
  { id: '11', title: 'Ghar Pe Restaurant Jaisi Biryani Kaise Banao', thumbnail: 'https://picsum.photos/seed/v11/640/360', views: 2800000, duration: '20:10', channelName: 'Rasoi Queen', avatar: 'R', createdAt: '5 din pehle', isVerified: true, category: 'Food' },
  { id: '12', title: 'Startup ki Kahani - Zero se Crore Tak', thumbnail: 'https://picsum.photos/seed/v12/640/360', views: 560000, duration: '35:25', channelName: 'Business Bharat', avatar: 'B', createdAt: '1 hafta pehle', isVerified: false, category: 'Business' },
]

function formatViews(views) {
  if (views >= 10000000) return (views / 10000000).toFixed(1) + 'Cr'
  if (views >= 100000) return (views / 100000).toFixed(1) + 'L'
  if (views >= 1000) return (views / 1000).toFixed(1) + 'K'
  return views
}

export default function HomePage() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [videos, setVideos] = useState(MOCK_VIDEOS)
  const [loading, setLoading] = useState(false)
  const [showStickers, setShowStickers] = useState(false)

  const handleCategoryChange = (cat) => {
    setActiveCategory(cat)
    setLoading(true)
    setTimeout(() => {
      if (cat === 'All') {
        setVideos(MOCK_VIDEOS)
      } else {
        setVideos(MOCK_VIDEOS.filter(v => v.category === cat || Math.random() > 0.4))
      }
      setLoading(false)
    }, 400)
  }

  return (
    <div className="min-h-screen pb-20">

      {/* Hero Banner */}
      <div className="relative overflow-hidden mx-4 mt-4 rounded-3xl 
                      bg-gradient-to-r from-bharat-saffron/20 via-orange-500/10 to-bharat-green/10
                      border border-white/10 p-8 md:p-12 mb-6">
        {/* BG decorations */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-bharat-saffron/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-bharat-green/5 rounded-full blur-3xl" />
        
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-4">
            <span className="badge bg-bharat-saffron/20 text-bharat-saffron border border-bharat-saffron/30">
              <HiSparkles /> New: AI Smart Clips
            </span>
            <span className="badge bg-white/10 text-white/60 border border-white/10">
              🇮🇳 Made for Bharat
            </span>
          </div>
          
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 leading-tight">
            Bharat Ki <span className="gradient-text">Awaaz</span>
          </h1>
          <p className="text-xl text-white/50 font-hindi mb-6">भारत की आवाज़, डिजिटल दुनिया में</p>
          <p className="text-white/60 mb-8 max-w-lg leading-relaxed">
            India's most advanced AI-powered video platform. Upload, discover, and share 
            content in Hindi, English, and all Indian languages.
          </p>
          
          <div className="flex flex-wrap gap-3">
            <Link href="/upload" className="btn-primary flex items-center gap-2 text-sm">
              <MdPlayArrow className="text-lg" />
              Video Upload Karo
            </Link>
            <Link href="/trending" className="btn-secondary flex items-center gap-2 text-sm">
              <MdLocalFireDepartment className="text-bharat-saffron text-lg" />
              Trending Dekho
            </Link>
            <Link href="/ai-studio" className="btn-secondary flex items-center gap-2 text-sm">
              <MdOutlineAutoAwesome className="text-purple-400 text-lg" />
              AI Studio
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="absolute bottom-6 right-8 hidden lg:flex gap-8">
          {[
            { value: '10L+', label: 'Videos' },
            { value: '5Cr+', label: 'Views/Day' },
            { value: '50L+', label: 'Creators' },
          ].map((stat, i) => (
            <div key={i} className="text-right">
              <p className="font-display font-bold text-2xl gradient-text">{stat.value}</p>
              <p className="text-xs text-white/30">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Categories Filter */}
      <div className="flex items-center gap-3 overflow-x-auto px-4 pb-4 
                      scrollbar-none no-scrollbar">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.label}
            onClick={() => handleCategoryChange(cat.label)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl 
                       text-sm font-medium transition-all duration-200 
                       ${activeCategory === cat.label
                         ? 'bg-bharat-saffron text-white shadow-lg shadow-orange-500/30'
                         : 'bg-white/5 border border-white/10 text-white/60 hover:text-white hover:bg-white/10'
                       }`}
          >
            <span>{cat.emoji}</span>
            {cat.label}
          </button>
        ))}
      </div>

      {/* Trending Badge */}
      <div className="flex items-center gap-3 px-4 mb-4">
        <div className="flex items-center gap-2 text-bharat-saffron font-semibold text-sm">
          <FiTrendingUp />
          <span>Trending in India</span>
        </div>
        <div className="flex-1 h-px bg-white/5" />
        <button 
          onClick={() => setShowStickers(!showStickers)}
          className="text-xs text-white/40 hover:text-white/70 transition-colors">
          {showStickers ? 'Hide' : 'Show'} Stickers 🎨
        </button>
      </div>

      {/* Stickers Panel */}
      {showStickers && <StickersPanel />}

      {/* Video Grid */}
      <div className="px-4">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array(8).fill(0).map((_, i) => (
              <div key={i} className="skeleton rounded-2xl aspect-video" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {videos.map((video) => (
              <VideoCard key={video.id} video={video} formatViews={formatViews} />
            ))}
          </div>
        )}
      </div>

    </div>
  )
}
