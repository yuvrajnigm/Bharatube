import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request) {
  try {
    const formData = await request.formData()
    const title = formData.get('title')
    const description = formData.get('description')
    const category = formData.get('category')
    const language = formData.get('language')
    const tags = formData.get('tags')
    const isPublic = formData.get('isPublic') === 'true'
    const videoFile = formData.get('video')

    if (!title || !videoFile) {
      return NextResponse.json(
        { error: 'Title aur video file required hai' },
        { status: 400 }
      )
    }

    // In production: Upload to AWS S3
    // const s3Url = await uploadToS3(videoFile)
    // const thumbnailUrl = await generateThumbnail(s3Url)
    // const hlsUrl = await convertToHLS(s3Url)

    // For demo: use placeholder URLs
    const videoId = `vid_${Date.now()}`
    const videoUrl = `https://your-cdn.cloudfront.net/videos/${videoId}.mp4`
    const thumbnail = `https://picsum.photos/seed/${videoId}/640/360`

    // Save to DB
    const video = await prisma.video.create({
      data: {
        id: videoId,
        title,
        description: description || '',
        videoUrl,
        thumbnail,
        category: category || 'General',
        language: language || 'Hindi',
        tags: JSON.stringify(tags ? tags.split(',').map(t => t.trim()) : []),
        isPublic,
        userId: 'demo-user-id', // Replace with actual auth user
        fileSize: videoFile.size || 0,
      }
    })

    // Trigger AI processing (async)
    // await triggerAIProcessing(videoId, videoUrl)

    return NextResponse.json({
      success: true,
      videoId: video.id,
      message: 'Video successfully upload ho gaya!',
      video: {
        id: video.id,
        title: video.title,
        videoUrl: video.videoUrl,
        thumbnail: video.thumbnail,
      }
    })

  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { error: 'Upload failed. Dobara try karein.' },
      { status: 500 }
    )
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const language = searchParams.get('language')
    const limit = parseInt(searchParams.get('limit') || '20')
    const page = parseInt(searchParams.get('page') || '1')

    const where = { isPublic: true }
    if (category && category !== 'All') where.category = category
    if (language) where.language = language

    const [videos, total] = await Promise.all([
      prisma.video.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: (page - 1) * limit,
        include: {
          user: {
            select: { name: true, channelName: true, isVerified: true, avatar: true }
          }
        }
      }),
      prisma.video.count({ where })
    ])

    return NextResponse.json({
      videos,
      pagination: {
        total,
        pages: Math.ceil(total / limit),
        currentPage: page,
        hasMore: page < Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Fetch error:', error)
    return NextResponse.json({ error: 'Videos fetch nahi ho sake' }, { status: 500 })
  }
}
