import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

export async function POST(request) {
  try {
    const { title, description, category } = await request.json()

    const prompt = `You are an expert YouTube/video content optimizer for Indian creators. 
Analyze this video and provide optimization suggestions in JSON format.

Video Title: ${title}
Description: ${description || 'Not provided'}
Category: ${category}

Return ONLY valid JSON with these fields:
{
  "improvedTitle": "optimized title with keywords (max 100 chars)",
  "tags": ["tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "tag7", "tag8"],
  "description": "improved description with timestamps and CTAs",
  "thumbnail_tips": "specific thumbnail design advice",
  "best_post_time": "best time to post this video in India",
  "predicted_views": "estimated views in first week",
  "viral_score": 7.5
}`

    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7,
      max_tokens: 800,
      response_format: { type: 'json_object' }
    })

    const suggestions = JSON.parse(response.choices[0].message.content)

    return NextResponse.json(suggestions)

  } catch (error) {
    console.error('AI suggest error:', error)
    
    // Fallback suggestions if OpenAI fails
    const { title, category } = await request.json().catch(() => ({}))
    return NextResponse.json({
      improvedTitle: `${title} | Complete Guide 2024 | Hindi`,
      tags: ['india', 'viral', 'trending', category?.toLowerCase() || 'video', 'hindi', '2024', 'bharat', 'desi'],
      description: `${title}\n\n📌 Is video mein aap seekhenge:\n✅ Complete information\n✅ Step by step guide\n✅ Tips aur tricks\n\n🔔 Channel Subscribe karo!\n👍 Video pasand aayi toh like karo\n💬 Comment mein batao kya lagaa`,
      thumbnail_tips: 'Bold text use karein, bright background, aapka face dikhao, curiosity gap create karo',
      best_post_time: 'Saturday ya Sunday - Evening 6-9 PM IST',
      predicted_views: '50,000 - 200,000 views first week',
      viral_score: 6.8
    })
  }
}
