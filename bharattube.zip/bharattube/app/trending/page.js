'use client'
import { useState } from 'react'
import { MdLocalFireDepartment, MdArrowUpward, MdPlayArrow } from 'react-icons/md'
import VideoCard from '@/components/VideoCard'

const TRENDING = [
  { id: 't1', title: '#1 — IPL 2024 Finals - RCB vs CSK Last Over Thriller 🏏', thumbnail: 'https://picsum.photos/seed/t1/640/360', views: 8900000, duration: '12:30', channelName: 'Cricket Adda', avatar: 'C', createdAt: '6 ghante pehle', isVerified: true, category: 'Cricket', rank: 1 },
  { id: 't2', title: '#2 — PM Modi Ki Nayi Yojana - Kya Mila Common Man Ko?', thumbnail: 'https://picsum.photos/seed/t2/640/360', views: 5600000, duration: '18:45', channelName: 'India News 24', avatar: 'I', createdAt: '3 ghante pehle', isVerified: true, category: 'News', rank: 2 },
  { id: 't3', title: '#3 — Viral Dance - Pushpa 2 Song Pe Desi Twist 💃', thumbnail: 'https://picsum.photos/seed/t3/640/360', views: 4200000, duration: '5:20', channelName: 'Dance India Dance', avatar: 'D', createdAt: '1 din pehle', isVerified: false, category: 'Dance', rank: 3 },
  { id: 't4', title: '#4 — Chandrayaan-4 Update - ISRO Ka Naya Mission', thumbnail: 'https://picsum.photos/seed/t4/640/360', views: 3800000, duration: '22:10', channelName: 'Science India', avatar: 'S', createdAt: '8 ghante pehle', isVerified: true, category: 'Education', rank: 4 },
  { id: 't5', title: '#5 — Budget 2024 - Middle Class Ke Liye Kya Hai?', thumbnail: 'https://picsum.photos/seed/t5/640/360', views: 3100000, duration: '30:00', channelName: 'Money Guru', avatar: 'M', createdAt: '12 ghante pehle', isVerified: true, category: 'Business', rank: 5 },
  { id: 't6', title: '#6 — Street Comedy - Boss Vs Employee 😂', thumbnail: 'https://picsum.photos/seed/t6/640/360', views: 2900000, duration: '8:15', channelName: 'Hasao Hasao', avatar: 'H', createdAt: '2 din pehle', isVerified: true, category: 'Comedy', rank: 6 },
]

function formatViews(views) {
  if (views >= 10000000) return (views / 10000000).toFixed(1) + 'Cr'
  if (views >= 100000) return (views / 100000).toFixed(1) + 'L'
  if (views >= 1000) return (views / 1000).toFixed(1) + 'K'
  return views
}

export default function TrendingPage() {
  const [activeTab, setActiveTab] = useState('India')
  const tabs = ['India', 'Music', 'Gaming', 'News', 'Cricket', 'Comedy']

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 
                         flex items-center justify-center shadow-lg shadow-red-500/30">
            <MdLocalFireDepartment size={28} className="text-white" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-white">Trending</h1>
            <p className="text-white/40 text-sm">Abhi Bharat Mein Kya Viral Hai</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 no-scrollbar">
          {tabs.map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-shrink-0 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all
                         ${activeTab === tab
                           ? 'bg-bharat-saffron text-white shadow-lg shadow-orange-500/30'
                           : 'bg-white/5 text-white/50 border border-white/10 hover:text-white hover:bg-white/10'}`}>
              {tab}
            </button>
          ))}
        </div>

        {/* Featured - #1 Trending */}
        <div className="relative rounded-3xl overflow-hidden mb-8 group cursor-pointer">
          <img src={TRENDING[0].thumbnail} alt={TRENDING[0].title}
            className="w-full aspect-[21/9] object-cover group-hover:scale-105 transition-transform duration-500" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="flex items-center gap-2 mb-3">
              <span className="badge bg-red-500 text-white border-0 text-sm px-3 py-1">
                🔥 #1 Trending in India
              </span>
              <span className="badge bg-white/10 text-white/70 border border-white/20">
                {TRENDING[0].category}
              </span>
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-3 max-w-3xl leading-tight">
              {TRENDING[0].title.replace('#1 — ', '')}
            </h2>
            <div className="flex items-center gap-4 text-white/60 text-sm">
              <span className="font-semibold text-white">{TRENDING[0].channelName}</span>
              <span>•</span>
              <span>{formatViews(TRENDING[0].views)} views</span>
              <span>•</span>
              <span>{TRENDING[0].createdAt}</span>
            </div>
          </div>
          {/* Play button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center
                           opacity-0 group-hover:opacity-100 scale-75 group-hover:scale-100 transition-all duration-300">
              <MdPlayArrow size={32} className="text-white ml-1" />
            </div>
          </div>
        </div>

        {/* Trending List */}
        <div className="space-y-4 mb-8">
          {TRENDING.slice(1).map((video, i) => (
            <a key={video.id} href={`/video/${video.id}`}
              className="flex gap-4 card p-4 hover:border-white/20 cursor-pointer group">
              <div className="flex-shrink-0 w-8 font-display font-bold text-2xl text-white/20 
                             flex items-center justify-center group-hover:text-bharat-saffron transition-colors">
                {i + 2}
              </div>
              <div className="w-40 flex-shrink-0 rounded-xl overflow-hidden aspect-video bg-white/5">
                <img src={video.thumbnail} alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-white mb-1 line-clamp-2 leading-snug
                               group-hover:text-bharat-saffron transition-colors">
                  {video.title.replace(/#\d+ — /, '')}
                </h3>
                <p className="text-white/40 text-sm mb-1">{video.channelName}</p>
                <div className="flex items-center gap-3 text-xs text-white/30">
                  <span>{formatViews(video.views)} views</span>
                  <span>•</span>
                  <span>{video.createdAt}</span>
                  <span className="badge bg-white/5 border border-white/10 ml-1">{video.category}</span>
                </div>
              </div>
              <div className="flex-shrink-0 flex flex-col items-end justify-center gap-2">
                <span className="flex items-center gap-1 text-bharat-green text-xs font-semibold">
                  <MdArrowUpward size={14} /> Trending
                </span>
                <span className="text-white/30 text-xs">{video.duration}</span>
              </div>
            </a>
          ))}
        </div>

        {/* More Videos Grid */}
        <h2 className="font-display font-bold text-white text-xl mb-4">Aur Videos</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {TRENDING.map(v => <VideoCard key={v.id} video={v} formatViews={formatViews} />)}
        </div>
      </div>
    </div>
  )
}
