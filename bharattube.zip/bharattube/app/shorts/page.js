'use client'
import { useState, useRef } from 'react'
import { MdFavorite, MdComment, MdShare, MdMusicNote, MdArrowUpward, MdArrowDownward } from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'

const SHORTS = [
  { id: 's1', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4', title: 'Dilli ki best chai ☕🔥', channel: 'Street Food India', likes: 45000, comments: 1200, shares: 8900, song: 'Chaiyya Chaiyya — AR Rahman' },
  { id: 's2', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', title: 'Cricket trick shot 🏏💥', channel: 'Cricket Adda', likes: 123000, comments: 4500, shares: 23000, song: 'Dhan Te Nan — Kaminey' },
  { id: 's3', videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', title: 'Mountains of Himachal 🏔️✨', channel: 'Desi Explorer', likes: 67000, comments: 2300, shares: 11000, song: 'Ik Vaari Aa — Raabta' },
]

function formatNum(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M'
  if (n >= 1000) return (n / 1000).toFixed(0) + 'K'
  return n
}

function Short({ short, isActive }) {
  const videoRef = useRef(null)
  const [liked, setLiked] = useState(false)
  const [likes, setLikes] = useState(short.likes)

  const handleLike = () => {
    setLiked(!liked)
    setLikes(prev => liked ? prev - 1 : prev + 1)
  }

  return (
    <div className="relative w-full h-full snap-start flex-shrink-0" style={{ height: 'calc(100vh - 64px)' }}>
      {/* Video */}
      <video
        ref={videoRef}
        src={short.videoUrl}
        className="absolute inset-0 w-full h-full object-cover"
        loop
        muted
        autoPlay={isActive}
        playsInline
      />

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-6 flex items-end gap-4">
        {/* Info */}
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-bharat-saffron to-orange-600 
                           flex items-center justify-center text-white text-xs font-bold">
              {short.channel[0]}
            </div>
            <span className="text-white font-semibold text-sm">{short.channel}</span>
            <button className="text-xs border border-white/50 text-white px-3 py-0.5 rounded-full 
                               hover:bg-white/10 transition-all">
              Follow
            </button>
          </div>
          <p className="text-white text-base font-medium mb-3 leading-snug max-w-xs">
            {short.title}
          </p>
          <div className="flex items-center gap-2 text-white/70 text-xs">
            <MdMusicNote className="text-bharat-saffron animate-spin-slow" />
            <span className="truncate max-w-[180px]">{short.song}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col items-center gap-5 pb-2">
          <button
            onClick={handleLike}
            className="flex flex-col items-center gap-1">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center
                            transition-all duration-200 active:scale-90
                            ${liked
                              ? 'bg-red-500 text-white scale-110'
                              : 'bg-white/10 text-white hover:bg-white/20'}`}>
              <MdFavorite size={22} />
            </div>
            <span className="text-white/80 text-xs font-medium">{formatNum(likes)}</span>
          </button>

          <button className="flex flex-col items-center gap-1">
            <div className="w-12 h-12 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-all">
              <MdComment size={22} />
            </div>
            <span className="text-white/80 text-xs font-medium">{formatNum(short.comments)}</span>
          </button>

          <button className="flex flex-col items-center gap-1">
            <div className="w-12 h-12 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-all">
              <MdShare size={22} />
            </div>
            <span className="text-white/80 text-xs font-medium">{formatNum(short.shares)}</span>
          </button>

          <button className="flex flex-col items-center gap-1">
            <div className="w-12 h-12 rounded-full bg-bharat-saffron/20 border border-bharat-saffron/30 
                           flex items-center justify-center hover:bg-bharat-saffron/30 transition-all">
              <HiSparkles className="text-bharat-saffron text-xl" />
            </div>
            <span className="text-white/50 text-xs">AI Clip</span>
          </button>
        </div>
      </div>

      {/* Nav hints */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-3 opacity-30">
        <MdArrowUpward className="text-white text-xl" />
        <MdArrowDownward className="text-white text-xl" />
      </div>
    </div>
  )
}

export default function ShortsPage() {
  const [activeIndex, setActiveIndex] = useState(0)
  const containerRef = useRef(null)

  const handleScroll = (e) => {
    const container = e.target
    const index = Math.round(container.scrollTop / container.clientHeight)
    setActiveIndex(index)
  }

  return (
    <div className="fixed inset-0 top-[67px] bg-black">
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="h-full overflow-y-scroll snap-y snap-mandatory scroll-smooth"
        style={{ scrollbarWidth: 'none' }}>
        {SHORTS.map((short, i) => (
          <Short key={short.id} short={short} isActive={i === activeIndex} />
        ))}
      </div>

      {/* Progress dots */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
        {SHORTS.map((_, i) => (
          <div key={i}
            className={`rounded-full transition-all duration-300
                       ${i === activeIndex ? 'w-1.5 h-6 bg-bharat-saffron' : 'w-1.5 h-1.5 bg-white/30'}`} />
        ))}
      </div>
    </div>
  )
}
