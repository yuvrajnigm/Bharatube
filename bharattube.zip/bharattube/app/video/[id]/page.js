'use client'
import { useState, useRef } from 'react'
import { 
  MdThumbUp, MdThumbDown, MdShare, MdDownload,
  MdVerified, MdNotifications, MdMoreHoriz,
  MdAutoAwesome, MdSubtitles, MdFullscreen,
  MdPlayArrow, MdPause, MdVolumeUp, MdVolumeMute
} from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'
import StickersPanel from '@/components/StickersPanel'
import toast from 'react-hot-toast'

const MOCK_VIDEO = {
  id: '1',
  title: 'Dilli Ki Sabse Badi Market Tour 2024 — Complete Guide',
  description: `Dilli ki sabse famous aur badi market ka complete tour! Is video mein aap dekhenge:
  
✅ Chandni Chowk ki puri galliyan
✅ Street food recommendations
✅ Shopping tips aur best deals
✅ Local secrets jo sirf Dilli waale jaante hain

📌 Timestamps:
00:00 - Introduction
02:30 - Chandni Chowk Entry
08:15 - Best Street Food
15:40 - Shopping Guide
22:00 - Hidden Gems
28:30 - Wrap Up

🔔 Subscribe karo aur bell icon dabao!
#Dilli #Delhi #StreetFood #Travel #India`,
  channelName: 'Desi Explorer',
  subscribers: '12.4L',
  views: 1200000,
  likes: 48000,
  createdAt: '2 din pehle',
  isVerified: true,
  duration: '18:42',
  category: 'Travel',
  language: 'Hindi',
  videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  thumbnail: 'https://picsum.photos/seed/v1/1280/720',
  aiSummary: 'Delhi ki famous Chandni Chowk market ka complete tour guide, street food recommendations ke saath.',
  hasAiClip: true,
}

const RELATED_VIDEOS = [
  { id: '2', title: 'Mumbai Street Food Tour', views: '890K', duration: '22:10', channel: 'Food Wanderer', thumbnail: 'https://picsum.photos/seed/r1/320/180' },
  { id: '3', title: 'Jaipur - Pink City Full Guide', views: '1.2M', duration: '34:20', channel: 'Desi Traveler', thumbnail: 'https://picsum.photos/seed/r2/320/180' },
  { id: '4', title: 'Kolkata Durga Puja 2024', views: '2.1M', duration: '45:00', channel: 'Bengal Diaries', thumbnail: 'https://picsum.photos/seed/r3/320/180' },
  { id: '5', title: 'Kerala Backwaters Trip', views: '670K', duration: '28:15', channel: 'South India Travel', thumbnail: 'https://picsum.photos/seed/r4/320/180' },
  { id: '6', title: 'Varanasi Ganga Aarti', views: '3.4M', duration: '15:30', channel: 'Spiritual India', thumbnail: 'https://picsum.photos/seed/r5/320/180' },
]

const COMMENTS = [
  { id: 1, user: 'Rahul S.', avatar: 'R', text: 'Bhai ekdum mast video hai! Main bhi Dilli jaana chahta hoon 🔥', likes: 342, time: '1 din pehle' },
  { id: 2, user: 'Priya M.', avatar: 'P', text: 'Chandni Chowk ke paranthe ki dukaan ka naam batao please! Kaafi baar gaya hun but acha paranthe wala nahi mila', likes: 189, time: '8 ghante pehle' },
  { id: 3, user: 'Amit K.', avatar: 'A', text: 'Bhai ye video meri job interview ki preparation ke time aaya - distraction ho gaya 😂😂', likes: 567, time: '2 din pehle' },
  { id: 4, user: 'Sneha R.', avatar: 'S', text: 'Great content! Please Agra ka bhi video banao 🙏', likes: 98, time: '5 ghante pehle' },
]

export default function VideoPage({ params }) {
  const [liked, setLiked] = useState(false)
  const [subscribed, setSubscribed] = useState(false)
  const [likeCount, setLikeCount] = useState(MOCK_VIDEO.likes)
  const [showAiSummary, setShowAiSummary] = useState(false)
  const [comment, setComment] = useState('')
  const [comments, setComments] = useState(COMMENTS)
  const [showFullDesc, setShowFullDesc] = useState(false)
  const videoRef = useRef(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)

  const handleLike = () => {
    setLiked(!liked)
    setLikeCount(prev => liked ? prev - 1 : prev + 1)
    if (!liked) toast('👍 Liked!', { duration: 1500 })
  }

  const handleSubscribe = () => {
    setSubscribed(!subscribed)
    toast(subscribed ? 'Unsubscribed' : `🔔 ${MOCK_VIDEO.channelName} ko subscribe kiya!`, { duration: 2000 })
  }

  const handleComment = () => {
    if (!comment.trim()) return
    setComments(prev => [{
      id: Date.now(), user: 'Aap', avatar: 'A',
      text: comment, likes: 0, time: 'Abhi'
    }, ...prev])
    setComment('')
    toast.success('Comment post ho gaya! 💬')
  }

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) { videoRef.current.pause() } else { videoRef.current.play() }
      setIsPlaying(!isPlaying)
    }
  }

  const formatNum = (n) => {
    if (n >= 100000) return (n / 100000).toFixed(1) + 'L'
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K'
    return n
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-screen-2xl mx-auto grid grid-cols-1 xl:grid-cols-3 gap-6">

        {/* Main Content */}
        <div className="xl:col-span-2 space-y-4">
          
          {/* Video Player */}
          <div className="relative rounded-2xl overflow-hidden bg-black group">
            <video
              ref={videoRef}
              src={MOCK_VIDEO.videoUrl}
              poster={MOCK_VIDEO.thumbnail}
              className="w-full aspect-video object-cover"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onClick={togglePlay}
            />

            {/* Custom Controls Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 
                           bg-gradient-to-t from-black/80 to-transparent
                           opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="progress-bar w-full mb-3 cursor-pointer" />
              <div className="flex items-center gap-3">
                <button onClick={togglePlay}
                  className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 
                             flex items-center justify-center transition-all">
                  {isPlaying ? <MdPause className="text-white" /> : <MdPlayArrow className="text-white" />}
                </button>
                <button onClick={() => { setIsMuted(!isMuted); if(videoRef.current) videoRef.current.muted = !isMuted }}
                  className="text-white/70 hover:text-white transition-colors">
                  {isMuted ? <MdVolumeMute /> : <MdVolumeUp />}
                </button>
                <span className="text-white/60 text-xs ml-2">{MOCK_VIDEO.duration}</span>
                <div className="flex-1" />
                <button className="text-white/70 hover:text-white transition-colors">
                  <MdSubtitles size={20} />
                </button>
                <button className="text-white/70 hover:text-white transition-colors">
                  <MdFullscreen size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* AI Summary */}
          <div className="card p-4">
            <button
              onClick={() => setShowAiSummary(!showAiSummary)}
              className="flex items-center justify-between w-full">
              <div className="flex items-center gap-2">
                <HiSparkles className="text-bharat-saffron text-lg" />
                <span className="font-semibold text-white text-sm">AI Smart Summary</span>
                <span className="badge bg-purple-500/20 text-purple-400 border border-purple-500/30 text-[10px]">
                  Beta
                </span>
              </div>
              <span className="text-white/30 text-sm">{showAiSummary ? '▲' : '▼'}</span>
            </button>
            {showAiSummary && (
              <div className="mt-3 p-3 bg-bharat-saffron/5 rounded-xl border border-bharat-saffron/10">
                <p className="text-white/70 text-sm leading-relaxed">{MOCK_VIDEO.aiSummary}</p>
                {MOCK_VIDEO.hasAiClip && (
                  <button className="mt-2 text-xs text-bharat-saffron hover:underline flex items-center gap-1">
                    <MdAutoAwesome size={14} /> 30-second AI Highlight dekho →
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Video Info */}
          <div className="space-y-4">
            <h1 className="font-display text-xl md:text-2xl font-bold text-white leading-tight">
              {MOCK_VIDEO.title}
            </h1>

            <div className="flex flex-wrap items-center justify-between gap-4">
              {/* Channel info */}
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-bharat-saffron to-orange-600 
                               flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  D
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <p className="font-semibold text-white text-sm">{MOCK_VIDEO.channelName}</p>
                    {MOCK_VIDEO.isVerified && <MdVerified className="text-bharat-saffron text-sm" />}
                  </div>
                  <p className="text-white/40 text-xs">{MOCK_VIDEO.subscribers} subscribers</p>
                </div>
                <button
                  onClick={handleSubscribe}
                  className={`ml-2 px-5 py-2 rounded-xl text-sm font-bold transition-all duration-200
                              ${subscribed
                                ? 'bg-white/10 text-white/60 hover:bg-red-500/20 hover:text-red-400'
                                : 'bg-bharat-saffron text-white hover:bg-orange-500 shadow-lg shadow-orange-500/30'}`}>
                  {subscribed ? (
                    <span className="flex items-center gap-1"><MdNotifications size={16} /> Subscribed</span>
                  ) : 'Subscribe'}
                </button>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleLike}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold
                             transition-all duration-200
                             ${liked
                               ? 'bg-bharat-saffron/20 text-bharat-saffron border border-bharat-saffron/30'
                               : 'bg-white/5 text-white/70 border border-white/10 hover:bg-white/10'}`}>
                  <MdThumbUp size={18} className={liked ? 'animate-bounce-in' : ''} />
                  {formatNum(likeCount)}
                </button>
                <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold
                                   bg-white/5 text-white/70 border border-white/10 hover:bg-white/10 transition-all">
                  <MdShare size={18} /> Share
                </button>
                <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold
                                   bg-white/5 text-white/70 border border-white/10 hover:bg-white/10 transition-all">
                  <MdDownload size={18} />
                </button>
              </div>
            </div>

            {/* Description */}
            <div className="card p-4">
              <div className="flex items-center gap-3 text-xs text-white/40 mb-3">
                <span className="font-semibold text-white/60">{formatNum(MOCK_VIDEO.views)} views</span>
                <span>•</span>
                <span>{MOCK_VIDEO.createdAt}</span>
                <span>•</span>
                <span className="badge bg-white/5 border border-white/10">{MOCK_VIDEO.language}</span>
                <span className="badge bg-white/5 border border-white/10">{MOCK_VIDEO.category}</span>
              </div>
              <div className={`text-white/70 text-sm leading-relaxed whitespace-pre-line 
                              ${!showFullDesc ? 'line-clamp-3' : ''}`}>
                {MOCK_VIDEO.description}
              </div>
              <button
                onClick={() => setShowFullDesc(!showFullDesc)}
                className="text-xs text-bharat-saffron mt-2 hover:underline">
                {showFullDesc ? 'Kam Karo ▲' : 'Aur Dekho ▼'}
              </button>
            </div>
          </div>

          {/* Stickers */}
          <StickersPanel />

          {/* Comments */}
          <div className="card p-5">
            <h3 className="font-display font-bold text-white mb-4 text-lg">
              💬 {comments.length} Comments
            </h3>

            {/* Add comment */}
            <div className="flex gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-bharat-saffron to-orange-600 
                             flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                A
              </div>
              <div className="flex-1">
                <input
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleComment()}
                  placeholder="Comment likhein..."
                  className="input-field text-sm"
                />
                {comment && (
                  <div className="flex justify-end gap-2 mt-2">
                    <button onClick={() => setComment('')} className="btn-secondary text-xs py-1.5 px-3">
                      Cancel
                    </button>
                    <button onClick={handleComment} className="btn-primary text-xs py-1.5 px-3">
                      Post
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Comment List */}
            <div className="space-y-5">
              {comments.map(c => (
                <div key={c.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center 
                                 text-white text-xs font-bold flex-shrink-0">
                    {c.avatar}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-semibold text-white">{c.user}</span>
                      <span className="text-xs text-white/30">{c.time}</span>
                    </div>
                    <p className="text-sm text-white/70 leading-relaxed">{c.text}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <button className="flex items-center gap-1 text-xs text-white/40 hover:text-bharat-saffron transition-colors">
                        <MdThumbUp size={14} /> {c.likes}
                      </button>
                      <button className="text-xs text-white/40 hover:text-white transition-colors">
                        Reply
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar - Related Videos */}
        <div className="space-y-4">
          <h3 className="font-display font-bold text-white text-lg">Aage Kya Dekhen</h3>
          <div className="space-y-3">
            {RELATED_VIDEOS.map(v => (
              <a key={v.id} href={`/video/${v.id}`}
                className="flex gap-3 group cursor-pointer">
                <div className="w-40 flex-shrink-0 rounded-xl overflow-hidden aspect-video bg-white/5">
                  <img src={v.thumbnail} alt={v.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white leading-snug line-clamp-2 
                               group-hover:text-bharat-saffron transition-colors mb-1">
                    {v.title}
                  </p>
                  <p className="text-xs text-white/40">{v.channel}</p>
                  <p className="text-xs text-white/30">{v.views} views • {v.duration}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
