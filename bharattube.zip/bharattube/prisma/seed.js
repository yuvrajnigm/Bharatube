const { PrismaClient } = require('@prisma/client')
const bcrypt = require('bcryptjs')

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding BharatTube database...')

  // Create demo users
  const users = await Promise.all([
    prisma.user.upsert({
      where: { email: 'demo@bharattube.in' },
      update: {},
      create: {
        id: 'user_demo',
        name: 'Demo Creator',
        email: 'demo@bharattube.in',
        password: await bcrypt.hash('bharattube123', 10),
        channelName: 'DemoChannel',
        bio: 'BharatTube ka demo creator',
        subscribers: 12400,
        totalViews: 1200000,
        isVerified: true,
      }
    }),
    prisma.user.upsert({
      where: { email: 'cricket@bharattube.in' },
      update: {},
      create: {
        id: 'user_cricket',
        name: 'Cricket Adda',
        email: 'cricket@bharattube.in',
        password: await bcrypt.hash('cricket123', 10),
        channelName: 'CricketAdda',
        subscribers: 450000,
        isVerified: true,
      }
    }),
  ])

  // Create sample videos
  const videoData = [
    {
      id: 'vid_001',
      title: 'Dilli Ki Sabse Badi Market Tour 2024',
      description: 'Chandni Chowk ki puri market ka tour',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      thumbnail: 'https://picsum.photos/seed/v1/640/360',
      duration: 1122,
      views: 1200000,
      likesCount: 48000,
      category: 'Travel',
      language: 'Hindi',
      tags: JSON.stringify(['dilli', 'delhi', 'market', 'travel', 'india']),
      userId: 'user_demo',
    },
    {
      id: 'vid_002',
      title: 'IPL 2024 Best Moments Compilation',
      description: 'IPL 2024 ke sabse best moments',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnail: 'https://picsum.photos/seed/v3/640/360',
      duration: 750,
      views: 3400000,
      likesCount: 145000,
      category: 'Cricket',
      language: 'Hindi',
      tags: JSON.stringify(['ipl', 'cricket', 'india', 'sports']),
      userId: 'user_cricket',
    },
    {
      id: 'vid_003',
      title: 'Python Programming - Zero to Hero Hindi Mein',
      description: 'Complete Python course Hindi mein',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      thumbnail: 'https://picsum.photos/seed/v7/640/360',
      duration: 2720,
      views: 780000,
      likesCount: 35000,
      category: 'Education',
      language: 'Hindi',
      tags: JSON.stringify(['python', 'programming', 'coding', 'hindi', 'tech']),
      userId: 'user_demo',
    },
  ]

  for (const video of videoData) {
    await prisma.video.upsert({
      where: { id: video.id },
      update: {},
      create: video,
    })
  }

  // Seed stickers
  const stickers = [
    { id: 's1', name: 'Fire', emoji: '🔥', category: 'Reactions' },
    { id: 's2', name: 'Heart', emoji: '❤️', category: 'Reactions' },
    { id: 's3', name: 'Laugh', emoji: '😂', category: 'Reactions' },
    { id: 's4', name: 'India', emoji: '🇮🇳', category: 'Bharat' },
    { id: 's5', name: 'Diya', emoji: '🪔', category: 'Bharat' },
    { id: 's6', name: 'Cricket', emoji: '🏏', category: 'Bharat' },
    { id: 's7', name: 'Rocket', emoji: '🚀', category: 'Vibes' },
    { id: 's8', name: 'Star', emoji: '⭐', category: 'Vibes' },
    { id: 's9', name: 'Clap', emoji: '👏', category: 'Support' },
    { id: 's10', name: 'Crown', emoji: '👑', category: 'Support' },
  ]

  for (const sticker of stickers) {
    await prisma.sticker.upsert({
      where: { id: sticker.id },
      update: {},
      create: sticker,
    })
  }

  console.log('✅ Seeding complete!')
  console.log(`   Users: ${users.length}`)
  console.log(`   Videos: ${videoData.length}`)
  console.log(`   Stickers: ${stickers.length}`)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
