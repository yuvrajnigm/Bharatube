'use client'
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  MdHome, MdLocalFireDepartment, MdVideoLibrary,
  MdSubscriptions, MdHistory, MdThumbUp,
  MdOutlineSmartDisplay, MdBarChart, MdSettings,
  MdOutlineAutoAwesome
} from 'react-icons/md'
import { FiYoutube } from 'react-icons/fi'
import { HiSparkles } from 'react-icons/hi2'

const mainNav = [
  { icon: <MdHome size={22} />, label: 'Home', href: '/' },
  { icon: <MdLocalFireDepartment size={22} />, label: 'Trending', href: '/trending' },
  { icon: <MdOutlineSmartDisplay size={22} />, label: 'Shorts', href: '/shorts' },
  { icon: <MdSubscriptions size={22} />, label: 'Subscriptions', href: '/subscriptions' },
]

const libraryNav = [
  { icon: <MdHistory size={22} />, label: 'Watch History', href: '/history' },
  { icon: <MdThumbUp size={22} />, label: 'Liked Videos', href: '/liked' },
  { icon: <MdVideoLibrary size={22} />, label: 'My Videos', href: '/my-videos' },
]

const categories = [
  '🎵 Music', '📰 News', '🎮 Gaming', '🍛 Food', '🎭 Comedy',
  '📚 Education', '🏏 Cricket', '🎬 Movies', '💃 Dance', '🧘 Yoga',
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="hidden lg:flex flex-col fixed left-0 top-[3px] bottom-0 w-64 
                      glass border-r border-white/5 overflow-y-auto z-30
                      scrollbar-thin scrollbar-track-transparent scrollbar-thumb-white/10">
      
      {/* Logo */}
      <div className="p-5 pb-4 border-b border-white/5">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-bharat-saffron to-orange-600 
                         flex items-center justify-center shadow-lg shadow-orange-500/20 
                         glow-border">
            <span className="text-white font-bold font-display text-lg">B</span>
          </div>
          <div>
            <h1 className="font-display font-bold text-xl text-white leading-none">
              Bharat<span className="text-bharat-saffron">Tube</span>
            </h1>
            <p className="text-[10px] text-white/30 mt-0.5">भारत की आवाज़</p>
          </div>
        </Link>
      </div>

      <div className="flex-1 p-3 space-y-6">
        
        {/* Main Nav */}
        <div className="space-y-1">
          {mainNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`nav-item ${pathname === item.href ? 'active' : ''}`}
            >
              {item.icon}
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          ))}
        </div>

        {/* AI Feature */}
        <div className="bg-gradient-to-r from-bharat-saffron/10 to-orange-500/5 
                        border border-bharat-saffron/20 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <HiSparkles className="text-bharat-saffron text-lg" />
            <span className="text-sm font-bold text-bharat-saffron font-display">AI Smart Clips</span>
          </div>
          <p className="text-xs text-white/40 mb-3 leading-relaxed">
            Auto-generate 30-second highlights from any video
          </p>
          <Link href="/ai-studio"
                className="text-xs font-semibold text-bharat-saffron hover:text-orange-400 
                           transition-colors flex items-center gap-1">
            <MdOutlineAutoAwesome />
            Try AI Studio →
          </Link>
        </div>

        {/* Library */}
        <div>
          <p className="text-[11px] font-semibold text-white/30 uppercase tracking-wider px-4 mb-2">
            Library
          </p>
          <div className="space-y-1">
            {libraryNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`nav-item ${pathname === item.href ? 'active' : ''}`}
              >
                {item.icon}
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div>
          <p className="text-[11px] font-semibold text-white/30 uppercase tracking-wider px-4 mb-2">
            Categories
          </p>
          <div className="space-y-1">
            {categories.map((cat) => (
              <button
                key={cat}
                className="nav-item w-full text-left text-sm"
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Bottom */}
      <div className="p-3 border-t border-white/5">
        <Link href="/analytics"
              className="nav-item">
          <MdBarChart size={22} />
          <span className="text-sm font-medium">Analytics</span>
        </Link>
        <Link href="/settings"
              className="nav-item">
          <MdSettings size={22} />
          <span className="text-sm font-medium">Settings</span>
        </Link>
        <p className="text-center text-[10px] text-white/15 mt-3 px-4">
          Made with ❤️ for Bharat
        </p>
      </div>
    </aside>
  )
}
