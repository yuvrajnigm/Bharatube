'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'

const STICKER_CATEGORIES = {
  'Reactions': ['🔥','❤️','😂','😍','🥳','😮','👏','💯','🤩','😎','🥺','😡'],
  'Bharat': ['🇮🇳','🪔','🕌','🛕','🎊','🌺','🦚','🐯','🌼','☮️','🎭','🏏'],
  'Vibes': ['🚀','⭐','💥','✨','⚡','🌟','💫','🎉','🎵','🎶','💃','🕺'],
  'Support': ['💪','👑','🙏','👍','🤝','💰','🏆','🎯','📈','💡','🔑','🌈'],
]

export default function StickersPanel() {
  const [activeTab, setActiveTab] = useState('Reactions')
  const [floating, setFloating] = useState([])
  const [counts, setCounts] = useState({})

  const handleStickerClick = (emoji) => {
    // Update count
    setCounts(prev => ({ ...prev, [emoji]: (prev[emoji] || 0) + 1 }))

    // Create floating animation
    const id = Date.now()
    const x = Math.random() * 80 + 10
    setFloating(prev => [...prev, { id, emoji, x }])
    setTimeout(() => {
      setFloating(prev => prev.filter(f => f.id !== id))
    }, 1800)

    toast(`${emoji} reaction sent!`, { duration: 1500, icon: emoji })
  }

  return (
    <div className="mx-4 mb-6 card p-4 relative overflow-hidden">
      {/* Floating stickers animation */}
      {floating.map(f => (
        <div key={f.id}
          className="absolute pointer-events-none text-3xl z-20"
          style={{
            left: `${f.x}%`,
            bottom: '100%',
            animation: 'floatUp 1.8s ease-out forwards',
          }}>
          {f.emoji}
        </div>
      ))}

      <style jsx>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(1); opacity: 1; }
          100% { transform: translateY(-120px) scale(0.5); opacity: 0; }
        }
      `}</style>

      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-display font-bold text-white text-sm">
          🎨 Live Reactions
        </h3>
        <div className="flex gap-1">
          {Object.keys(STICKER_CATEGORIES).map(tab => (
            <button key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition-all
                ${activeTab === tab
                  ? 'bg-bharat-saffron text-white'
                  : 'text-white/40 hover:text-white/70 hover:bg-white/5'}`}>
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Stickers Grid */}
      <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2">
        {STICKER_CATEGORIES[activeTab].map((emoji, i) => (
          <button key={i}
            onClick={() => handleStickerClick(emoji)}
            className="sticker-btn relative w-12 h-12 rounded-xl bg-white/5 
                       border border-white/10 flex flex-col items-center justify-center
                       hover:bg-bharat-saffron/10 hover:border-bharat-saffron/30 text-2xl">
            {emoji}
            {counts[emoji] > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-bharat-saffron 
                               rounded-full text-[9px] text-white flex items-center 
                               justify-center font-bold">
                {counts[emoji] > 9 ? '9+' : counts[emoji]}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Top reactions bar */}
      {Object.keys(counts).length > 0 && (
        <div className="mt-3 pt-3 border-t border-white/5 flex items-center gap-3">
          <span className="text-xs text-white/30">Top reactions:</span>
          <div className="flex gap-2">
            {Object.entries(counts)
              .sort(([,a],[,b]) => b - a)
              .slice(0, 5)
              .map(([emoji, count]) => (
                <span key={emoji} className="flex items-center gap-1 bg-white/5 
                                             rounded-full px-2 py-0.5 text-xs">
                  {emoji} <span className="text-white/50">{count}</span>
                </span>
              ))}
          </div>
        </div>
      )}
    </div>
  )
}
