'use client'
import { useState } from 'react'
import Link from 'next/link'
import { 
  FiSearch, FiBell, FiUpload, FiMenu, FiUser,
  FiMic, FiX, FiSettings, FiLogOut
} from 'react-icons/fi'
import { MdOutlineVideoCall } from 'react-icons/md'

export default function Navbar() {
  const [searchQuery, setSearchQuery] = useState('')
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [notifCount] = useState(3)

  return (
    <nav className="glass fixed top-[3px] left-0 right-0 z-40 h-16 flex items-center px-4 lg:px-6 gap-4 border-b border-white/5">
      
      {/* Logo (mobile only) */}
      <Link href="/" className="lg:hidden flex items-center gap-2 mr-2">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-bharat-saffron to-orange-600 flex items-center justify-center">
          <span className="text-white font-bold text-sm">BT</span>
        </div>
      </Link>

      {/* Search Bar */}
      <div className="flex-1 max-w-2xl mx-auto relative">
        <div className="relative flex items-center">
          <FiSearch className="absolute left-4 text-white/30 text-lg" />
          <input
            type="text"
            placeholder="Kuch bhi search karo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-l-xl 
                       pl-11 pr-4 py-2.5 text-white placeholder-white/30 text-sm
                       focus:outline-none focus:border-bharat-saffron/50 
                       focus:bg-white/8 transition-all"
          />
          <button className="bg-white/10 hover:bg-bharat-saffron/20 border border-white/10 
                             border-l-0 rounded-r-xl px-4 py-2.5 transition-all
                             hover:border-bharat-saffron/50">
            <FiSearch className="text-white/70 text-lg" />
          </button>
          <button className="ml-2 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 
                             border border-white/10 transition-all group">
            <FiMic className="text-white/50 group-hover:text-bharat-saffron transition-colors" />
          </button>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2">
        
        {/* Upload */}
        <Link href="/upload"
              className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl 
                         bg-bharat-saffron/10 border border-bharat-saffron/30 
                         text-bharat-saffron hover:bg-bharat-saffron hover:text-white 
                         transition-all text-sm font-semibold">
          <MdOutlineVideoCall className="text-lg" />
          <span className="hidden md:inline">Upload</span>
        </Link>

        {/* Notifications */}
        <button className="relative p-2.5 rounded-xl bg-white/5 hover:bg-white/10 
                           border border-white/10 transition-all">
          <FiBell className="text-white/70 text-lg" />
          {notifCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-bharat-saffron 
                             rounded-full text-white text-[10px] flex items-center 
                             justify-center font-bold">
              {notifCount}
            </span>
          )}
        </button>

        {/* User Avatar */}
        <div className="relative">
          <button 
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-bharat-saffron to-orange-600 
                       flex items-center justify-center font-bold text-white text-sm
                       hover:shadow-lg hover:shadow-orange-500/30 transition-all">
            U
          </button>
          
          {showUserMenu && (
            <div className="absolute right-0 top-12 w-56 bg-bharat-card border border-bharat-border 
                            rounded-2xl shadow-2xl py-2 animate-fade-in z-50">
              <div className="px-4 py-3 border-b border-bharat-border">
                <p className="font-semibold text-white text-sm">Mere Channel Pe</p>
                <p className="text-white/40 text-xs">user@example.com</p>
              </div>
              {[
                { icon: <FiUser />, label: 'My Channel', href: '/profile' },
                { icon: <FiSettings />, label: 'Settings', href: '/settings' },
                { icon: <FiUpload />, label: 'Upload Video', href: '/upload' },
              ].map((item, i) => (
                <Link key={i} href={item.href}
                      className="flex items-center gap-3 px-4 py-2.5 text-white/70 
                                 hover:text-white hover:bg-white/5 text-sm transition-colors">
                  <span className="text-bharat-saffron">{item.icon}</span>
                  {item.label}
                </Link>
              ))}
              <div className="border-t border-bharat-border mt-2 pt-2">
                <button className="flex items-center gap-3 px-4 py-2.5 text-red-400 
                                   hover:bg-red-500/10 w-full text-sm transition-colors">
                  <FiLogOut />
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  )
}
