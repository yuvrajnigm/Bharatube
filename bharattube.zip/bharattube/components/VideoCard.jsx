'use client'
import { useState } from 'react'
import Link from 'next/link'
import { MdVerified, MdMoreVert, MdWatchLater, MdPlaylistAdd, MdShare } from 'react-icons/md'
import { HiSparkles } from 'react-icons/hi2'

export default function VideoCard({ video, formatViews }) {
  const [showMenu, setShowMenu] = useState(false)
  const [imgError, setImgError] = useState(false)

  return (
    <div className="video-card relative group">
      {/* Thumbnail */}
      <Link href={`/video/${video.id}`} className="block relative overflow-hidden rounded-t-2xl">
        <div className="aspect-video bg-white/5 overflow-hidden">
          <img
            src={imgError ? `https://picsum.photos/seed/${video.id}/640/360` : video.thumbnail}
            alt={video.title}
            className="video-thumbnail w-full h-full object-cover"
            onError={() => setImgError(true)}
          />
        </div>

        {/* Duration badge */}
        <span className="absolute bottom-2 right-2 bg-black/80 text-white text-xs 
                         font-mono px-1.5 py-0.5 rounded-md">
          {video.duration}
        </span>

        {/* AI badge */}
        {video.hasAiClip && (
          <span className="absolute top-2 left-2 badge bg-purple-500/80 text-white 
                           border border-purple-400/30 backdrop-blur-sm">
            <HiSparkles size={10} /> AI Clip
          </span>
        )}

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 
                        transition-all duration-300 flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center
                          opacity-0 group-hover:opacity-100 scale-75 group-hover:scale-100
                          transition-all duration-300 shadow-xl">
            <div className="w-0 h-0 border-t-[8px] border-t-transparent border-b-[8px] 
                            border-b-transparent border-l-[14px] border-l-black ml-1" />
          </div>
        </div>
      </Link>

      {/* Info */}
      <div className="p-3 flex gap-3">
        {/* Avatar */}
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-bharat-saffron to-orange-600 
                        flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">
          {video.avatar}
        </div>

        <div className="flex-1 min-w-0">
          <Link href={`/video/${video.id}`}>
            <h3 className="text-sm font-semibold text-white leading-snug mb-1 
                           line-clamp-2 group-hover:text-bharat-saffron transition-colors">
              {video.title}
            </h3>
          </Link>
          <div className="flex items-center gap-1 text-white/40 text-xs mb-0.5">
            <span>{video.channelName}</span>
            {video.isVerified && (
              <MdVerified className="text-bharat-saffron text-sm" />
            )}
          </div>
          <p className="text-white/30 text-xs">
            {formatViews(video.views)} views • {video.createdAt}
          </p>
        </div>

        {/* More menu */}
        <div className="relative flex-shrink-0">
          <button
            onClick={(e) => { e.preventDefault(); setShowMenu(!showMenu) }}
            className="p-1 rounded-lg opacity-0 group-hover:opacity-100 
                       hover:bg-white/10 transition-all text-white/50 hover:text-white"
          >
            <MdMoreVert />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-8 w-44 bg-bharat-card border border-bharat-border 
                            rounded-xl shadow-2xl py-1 z-20 animate-fade-in">
              {[
                { icon: <MdWatchLater size={16} />, label: 'Watch Later' },
                { icon: <MdPlaylistAdd size={16} />, label: 'Playlist Mein Add' },
                { icon: <MdShare size={16} />, label: 'Share Karo' },
              ].map((item, i) => (
                <button key={i}
                  onClick={() => setShowMenu(false)}
                  className="flex items-center gap-3 w-full px-3 py-2 text-xs 
                             text-white/60 hover:text-white hover:bg-white/5 transition-colors">
                  <span className="text-bharat-saffron">{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
